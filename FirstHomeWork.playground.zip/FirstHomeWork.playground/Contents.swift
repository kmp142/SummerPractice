import UIKit

protocol HomeworkService {
    // Функция деления с остатком, должна вернуть в первой части результат деления, во второй части остаток.
    func divideWithRemainder(_ x: Int, by y: Int) -> (Int, Int)

    // Функция должна вернуть числа фибоначчи.
    func fibonacci(n: Int) -> [Int]

    // Функция должна выполнить сортировку пузырьком.
    func sort(rawArray: [Int]) -> [Int]

    // Функция должна преобразовать массив строк в массив первых символов строки.
    func firstLetter(strings: [String]) -> [Character]

    // Функция должна отфильтровать массив по условию, которое приходит в параметре `condition`. (Нельзя юзать `filter` у `Array`)
    func filter(array: [Int], condition: ((Int) -> Bool)) -> [Int]
}

struct HomeworkStruct: HomeworkService {
    
    func divideWithRemainder(_ x: Int, by y: Int) -> (Int, Int) {
        return (x/y, x%y)
    }
    
    func fibonacci(n: Int) -> [Int] {
        var firstNumber: Int = 1
        var secondNumber: Int = 1
        var arr: [Int] = [firstNumber, secondNumber]
        for _ in 2..<n {
            var value = secondNumber
            secondNumber = firstNumber + secondNumber
            firstNumber = value
            arr.append(secondNumber)
        }
        return arr
    }
    
    func sort(rawArray: [Int]) -> [Int] {
        var arr = rawArray
        for i in 0..<arr.count {
            
            let index = (arr.count - 1) - i
            
            for j in 0..<index {
                let number = arr[j]
                let nextNumber = arr[j+1]
                if number > nextNumber {
                    arr[j] = nextNumber
                    arr[j+1] = number
                }
            }
        }
        return arr
    }
    
    func firstLetter(strings: [String]) -> [Character] {
        var arr: [Character] = []
        for str in strings {
            arr.append(contentsOf: str.prefix(1))
        }
        return arr
        
    }
    
    func filter(array: [Int], condition: ((Int) -> Bool)) -> [Int] {
        var arr: [Int] = []
        for i in 0..<array.count {
            if condition(array[i]) {
                arr.append(array[i])
            }
        }
        return arr
    }
}




protocol Building {
    var height: Int {get set}
    var width: Int { get set }
}

protocol Worker {
    var jobTitle: String {get set}
    var salary: Int {get}
}

protocol Furniture {
    var height: Int {get set}
    var width: Int { get set }
    
}

class TatarstanNationalLibrary: Building {
    var height = 2000
    var width = 13000
    var color = "brown"
    var workers: [Worker]
    var furniture: [Furniture]
    
    func openAllDoors() {
        print("All doors are opened.")
    }
    
    func closeAllDoors() {
        print("All doors are closed")
    }
    
    init(height: Int, width: Int, color: String, workers: [Worker], furnitures: [Furniture]) {
        self.height = height
        self.width = width
        self.color = color
        self.workers = workers
        self.furniture = furnitures
    }
    
}

class Librarian: Worker {
    var jobTitle = "Librarian and cleaner"
    internal var salary: Int = 50000
    
    func takeSalary() {
        print("Librarian is taking salary")
    }
    
    func cleanFurniture() {
        print("Librarian is cleaning furniture")
    }
}

class LibrarianHelper: Librarian {
    private var probationDays = 30
    override func takeSalary() {
        print("Librarian helper is taking salary")
    }
    

}

class RepairMan: Worker {
    var jobTitle = "Fix all bugs"
    var salary = 45000
    var isBusy = false
    
    func startFixSmth() {
        isBusy = true
        print("RepairMan is busy")
    }
    
    func endFixSmth() {
        isBusy = false
        print("RepairMan is free")
    }
}

class Promoter: Worker {
    var  jobTitle = "PR-manager"
    var salary = 40000
    
    func makePromotion() {
        print("Promoter is trying to promote culture")
    }
}

struct Rack: Furniture {
    var height = 400
    var width = 1500
    var color = "white"
    var numberOfShelves = 6
    
}
